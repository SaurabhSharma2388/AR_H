import { useState, useRef } from "react";
import { Upload, Share2, Info, Maximize, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";

export default function ARViewer() {
  const [modelSrc, setModelSrc] = useState("https://modelviewer.dev/shared-assets/models/Astronaut.glb");
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'model' | 'video'>('model');
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);

    // Reset states
    setVideoSrc(null);

    // Check file type
    if (file.name.endsWith('.glb') || file.name.endsWith('.gltf')) {
      const url = URL.createObjectURL(file);
      setModelSrc(url);
      setMediaType('model');
      toast({
        title: "Model Loaded",
        description: "Your 3D model is ready to view in AR.",
      });
    } else if (file.type.startsWith('video/')) {
      const url = URL.createObjectURL(file);
      setVideoSrc(url);
      setMediaType('video');
      toast({
        title: "Video Loaded",
        description: "Video loaded for preview. Note: AR mode is limited for video content without 3D wrapping.",
      });
    } else if (file.type.startsWith('image/')) {
      toast({
        title: "Image Uploaded",
        description: "Note: 2D images cannot be fully converted to 3D AR models in this demo. Displaying default model for demonstration.",
        variant: "destructive"
      });
      setMediaType('model');
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a .glb, .gltf, or video file.",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-serif font-bold tracking-tight text-gray-900">OQEP HSE Demo</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="hidden sm:flex gap-2"
              onClick={triggerUpload}
            >
              <Upload className="w-4 h-4" />
              Upload Media
            </Button>
            <Button size="icon" variant="ghost">
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Viewer Area */}
      <main className="flex-1 relative bg-gray-50 overflow-hidden flex items-center justify-center">
        
        {mediaType === 'model' ? (
          <model-viewer
            src={modelSrc}
            ios-src="https://modelviewer.dev/shared-assets/models/Astronaut.usdz"
            alt="A 3D model of an astronaut"
            shadow-intensity="1"
            camera-controls
            auto-rotate
            ar
            ar-modes="webxr scene-viewer quick-look"
            class="w-full h-full block"
            style={{ width: '100%', height: '100%' }}
          >
            {/* AR Button Customization */}
            <button slot="ar-button" className="absolute bottom-8 right-8 bg-black text-white px-6 py-3 rounded-full font-medium shadow-lg hover:scale-105 transition-transform flex items-center gap-2 z-10">
              <Maximize className="w-5 h-5" />
              View in AR
            </button>
          </model-viewer>
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-black">
            {videoSrc && (
              <video 
                src={videoSrc} 
                controls 
                autoPlay 
                loop 
                className="max-w-full max-h-full w-auto h-auto object-contain"
              />
            )}
            <div className="absolute bottom-8 right-8 bg-black/50 text-white px-4 py-2 rounded-full text-sm backdrop-blur-md border border-white/20">
              Video Preview Mode
            </div>
          </div>
        )}

        {/* Loading Overlay */}
        {isLoading && (
          <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
          </div>
        )}

        {/* Mobile Upload Button (Floating) */}
        <Button 
          className="sm:hidden absolute bottom-8 left-8 rounded-full shadow-lg h-12 w-12 p-0"
          onClick={triggerUpload}
        >
          <Upload className="w-5 h-5" />
        </Button>

        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          accept=".glb,.gltf,image/*,video/*" 
          onChange={handleUpload} 
        />

        {/* Instructions Overlay */}
        <div className="absolute top-4 left-4 max-w-xs pointer-events-none">
          <Card className="p-4 bg-white/90 backdrop-blur shadow-sm border-none pointer-events-auto">
            <h3 className="font-medium mb-1 flex items-center gap-2">
              <Info className="w-4 h-4 text-blue-500" />
              {mediaType === 'model' ? 'How to use' : 'Video Mode'}
            </h3>
            <p className="text-sm text-gray-500">
              {mediaType === 'model' 
                ? 'Drag to rotate. Scroll to zoom. On mobile, tap "View in AR" to place the model in your room.'
                : 'You are viewing a video preview. Switch back to a 3D model to use AR features.'}
            </p>
          </Card>
        </div>
      </main>
    </div>
  );
}
